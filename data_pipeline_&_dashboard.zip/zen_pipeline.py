#!/usr/bin/python
# -*- coding: utf-8 -*-

# импортируем библиотеки
import sys
import getopt
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy import Table, Column, String, MetaData
if __name__ == "__main__":
    #Задаем входные параметры
    unixOptions = "s:e"
    gnuOptions = ["start_dt=", "end_dt="]
    
    fullCmdArguments = sys.argv
    argumentList = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, unixOptions, gnuOptions)
    except getopt.error as err:
        print (str(err))
        sys.exit(2)
    
    start_dt = ''
    end_dt = ''
    for currentArgument, currentValue in arguments:
        if currentArgument in ("-s", "--start_dt"):
            start_dt = currentValue
        elif currentArgument in ("-e", "--end_dt"):
            end_dt = currentValue
    
# Задаём параметры подключения к БД,
# их можно узнать у администратора БД.
    db_config = {'user': 'my_user',         # имя пользователя
                 'pwd': 'my_user_password', # пароль
                 'host': 'localhost',       # адрес сервера
                 'port': 5432,              # порт подключения
                 'db': 'zen'}               # название базы данных

# Формируем строку соединения с БД.
    connection_string = 'postgresql://{}:{}@{}:{}/{}'.format(db_config['user'],
                                                                     db_config['pwd'],
                                                                       db_config['host'],
                                                                       db_config['port'],
                                                                       db_config['db'])
# Подключаемся к БД.
    engine = create_engine(connection_string)

# Формируем sql-запрос.
    query = ''' SELECT *,
            TO_TIMESTAMP(ts/ 1000) AT TIME ZONE 'Etc/UTC' as dt
            FROM log_raw
            WHERE TO_TIMESTAMP(ts/1000) AT TIME ZONE 'Etc/UTC' BETWEEN '{}'::TIMESTAMP AND '{}'::TIMESTAMP;
            '''.format(start_dt, end_dt)

# Выполняем запрос и сохраняем результат
# выполнения в DataFrame.
    data_raw = pd.io.sql.read_sql(query, con = engine, index_col = 'event_id')

# Преобразуем данные к нужным типам.
    columns_numeric = ['item_id', 'source_id', 'user_id']
    columns_str = ['age_segment', 'event', 'item_topic', 'item_type', 'source_topic', 'source_type']

    for column in columns_numeric: data_raw[column] = pd.to_numeric(data_raw[column], errors='coerce')
    for column in columns_str: data_raw[column] = data_raw[column].astype(str)

    data_raw['dt'] = pd.to_datetime(data_raw['dt']).dt.round('min')

    dash_visits = data_raw.groupby(['item_topic', 'source_topic', 'age_segment', 'dt']).agg({'event':'count'}).reset_index().copy()

    dash_visits.columns = ['item_topic', 'source_topic', 'age_segment', 'dt', 'visits']


    dash_engagement = data_raw.groupby(['dt', 'item_topic', 'event', 'age_segment']).agg({'user_id':'nunique'}).reset_index().copy()

    dash_engagement.columns = ['dt', 'item_topic', 'event', 'age_segment', 'unique_users']

    for table in [dash_visits, dash_engagement]:
        table['dt'] = pd.to_datetime(table['dt'])
        
    tables = {'dash_visits':dash_visits, 'dash_engagement':dash_engagement}
    
#Удаляем старые записи между start_dt и end_dt
    
    for table_name, table_data in tables.items():
        query = '''DELETE FROM {} WHERE dt BETWEEN '{}'::TIMESTAMP AND '{}'::TIMESTAMP'''.format(table_name, start_dt, end_dt)
        engine.execute(query)
        
        table_data.to_sql(name = table_name, con = engine, if_exists = 'append', index = False)
    print('well done')