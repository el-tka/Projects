#!/usr/bin/python
# -*- coding: utf-8 -*-

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

import plotly.graph_objs as go

from datetime import datetime

import pandas as pd

# задаём данные для отрисовки
from sqlalchemy import create_engine

#подключение к базе данных для Postresql
db_config = {'user': 'my_user',
             'pwd': 'my_user_password',
             'host': 'localhost',
             'port': 5432,
             'db': 'zen'}
engine = create_engine('postgresql://{}:{}@{}:{}/{}'.format(db_config['user'],
                                                            db_config['pwd'],
                                                            db_config['host'],
                                                            db_config['port'],
                                                            db_config['db']))
query_visits = """SELECT * FROM dash_visits"""
query_engagement = """SELECT * FROM dash_engagement"""

dash_visits = pd.io.sql.read_sql(query_visits, con = engine)
dash_engagement = pd.io.sql.read_sql(query_engagement, con = engine)

for table in [dash_visits, dash_engagement]:
    table['dt'] = pd.to_datetime(table['dt']).dt.round('min')

note = '''Этот дашборд показывает: \
            количесво взаимодействий пользователей с карточками в системе с разбивкой по темам карточек; \
            количество карточек, которые генерируют источники с разными темами; \
            конверсию пользователей из показов карточек в просмотры статей.
            Используйте выбор даты и времени, темы карточки, темы источника, возрастной группы, типа события для управления дашбордом.
          Используйте селектор выбора режима отображения для того, чтобы показать абсолютные
          или относительные значения количества взаимодействия пользователей.
            '''
#лейаут 
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets = external_stylesheets)
app.layout = html.Div(children=[
	# формируем заголовок
    html.H1(children = 'Aнализ взаимодействия пользователей с сервисом Яндекс.Дзен'),
    html.Br(),
        
    html.Label(note),
    
    html.Br(),

    html.Div([
        
        html.Div([
            html.Label('Темы источника'),
            dcc.Dropdown(
                options = [{'label':x, 'value':x} for x in dash_visits['item_topic'].unique()],
                value = dash_visits['item_topic'].unique().tolist(),
                multi = True,
                id = 'item_topic_dropdown',
            ),
        ], className = 'six columns'),


        html.Div([
            html.Label('Возрастные категории:'),
            dcc.Dropdown(
                options = [{'label':x, 'value':x} for x in dash_engagement['age_segment'].unique()],
                value = dash_engagement['age_segment'].unique().tolist(),
                multi = True,
                id = 'age_dropdown',
            ),
            
        ], className = 'two columns'),


        html.Div([
            html.Label('Выбор даты и времени'),
            dcc.DatePickerRange(
                start_date = dash_visits['dt'].min(),
                end_date = dash_visits['dt'].max(),
                display_format = 'YYYY-MM-DD',
                id = 'dt_selector',
            ),
        ], className = 'four columns'),
    
        ], className = 'row'),

    html.Br(),
    html.Br(),

    html.Div([
        html.Div([
            html.Label('История событий по темам карточек'),
            dcc.Graph(
                style = {'height': '50vw'},
                id = 'history_absolute_visits'
                ),],
                className = 'six columns'
        ),

        html.Div([
            html.Label('График разбивки событий по темам источников'),
            html.Br(),
            dcc.Graph(
                style = {'height': '50vw'},
                id = 'pie_visits'),

            html.Label('Средняя глубина взаимодействия'),
            html.Br(),
            dcc.Graph(
                style = {'height': '25vw'},
                id = 'engagement_graph'),
        ], className = 'six columns'),
    ], className = 'row'),
])

#описываем логику дашборда
@app.callback(
    [Output('history_absolute_visits', 'figure'),
     Output('pie_visits', 'figure'),
     Output('engagement_graph', 'figure'),
    ],

    [Input('age_dropdown', 'value'),
     Input('item_topic_dropdown', 'value'),
     Input('dt_selector', 'start_date'),
     Input('dt_selector', 'end_date')])


def update_figures(selected_ages, selected_item_topics, start_date, end_date):
    #отфильтруем данные 
    dash_visits_filtered = dash_visits.query('item_topic.isin(@selected_item_topics) and \
                                              dt >= @start_date and dt <= @end_date \
                                              and age_segment.isin(@selected_ages)')
    dash_engagement_filtered = dash_engagement.query('item_topic.isin(@selected_item_topics) and \
                                                    dt >= @start_date and dt <= @end_date \
                                                    and age_segment.isin(@selected_ages)')
    visits_by_item_topic = dash_visits_filtered.groupby(['item_topic', 'dt']).agg({'visits':'sum'}).reset_index()
	
    visits_by_source_topic = dash_visits_filtered.groupby(['source_topic']).agg({'visits':'sum'}).reset_index()
    
    engagement_by_event = dash_engagement_filtered.groupby('event').agg({'unique_users':'mean'}).reset_index()
    engagement_by_event.columns = ['event', 'avg_unique_users']
    engagement_by_event = engagement_by_event.sort_values('avg_unique_users', ascending = False)

    #График История событий по темам карточек
    data_by_visits = []
    for item in visits_by_item_topic['item_topic'].unique():
      data_by_visits += [go.Scatter(x = visits_by_item_topic.query('item_topic == @item')['dt'],
                                   y = visits_by_item_topic.query('item_topic == @item')['visits'],
                                   mode = 'lines',
                                   stackgroup = 'one',
                                   name = item)]

    # График разбивки событий по темам источников
    data_by_source = [go.Pie(labels = visits_by_source_topic['source_topic'],
                             values = visits_by_source_topic['visits'],
                             name = 'source_visits')]

    #График средней глубины взаимодействия
    data_by_engagement = []
    for event in engagement_by_event['event'].unique():
        data_by_engagement += [go.Bar(x = engagement_by_event['event'], y = engagement_by_event['avg_unique_users'], name = event)]

    #формируем результат для отображения
    return(
            {'data':data_by_visits,
            'layout': go.Layout(xaxis = {'title': 'дата'},
                                yaxis = {'title': 'количество взаимодействий'})},
            {'data': data_by_source,
             'layout': go.Layout()},
            
            {'data': data_by_engagement,
             'layout': go.Layout(xaxis = {'title': 'событие'}, yaxis = {'title': 'среднее количество взаимодействий'})})

if __name__ == '__main__':
    app.run_server(host='0.0.0.0', port=3000) 